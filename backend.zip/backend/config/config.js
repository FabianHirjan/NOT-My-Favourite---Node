module.exports = {
    development : {
        username : "postgres",
        password : "",
        database : "nofdatabase",
        host : "localhost",
        dialect : "postgres",
    },
};